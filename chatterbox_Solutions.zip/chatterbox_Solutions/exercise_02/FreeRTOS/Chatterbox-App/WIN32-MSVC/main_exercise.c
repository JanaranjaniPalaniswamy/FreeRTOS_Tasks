/*
 * FreeRTOS Kernel V10.1.1
 * Copyright (C) 2018 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://www.FreeRTOS.org
 * http://aws.amazon.com/freertos
 *
 * 1 tab == 4 spaces!
 */

/******************************************************************************
 * NOTE: Windows will not be running the FreeRTOS project threads continuously, so
 * do not expect to get real time behaviour from the FreeRTOS Windows port, or
 * this project application.  Also, the timing information in the FreeRTOS+Trace
 * logs have no meaningful units.  See the documentation page for the Windows
 * port for further information:
 * http://www.freertos.org/FreeRTOS-Windows-Simulator-Emulator-for-Visual-Studio-and-Eclipse-MingW.html
 *
 * NOTE 2:  This file only contains the source code that is specific to exercise 2
 * Generic functions, such FreeRTOS hook functions, are defined
 * in main.c.
 ******************************************************************************
 *
 * NOTE:  Console input and output relies on Windows system calls, which can
 * interfere with the execution of the FreeRTOS Windows port.  This demo only
 * uses Windows system call occasionally.  Heavier use of Windows system calls
 * can crash the port.
 */

/* Standard includes. */
#include <stdio.h>
#include <conio.h>
#include <string.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"


/* TODO: Priorities at which the tasks are created.*/
#define mainTASK_ONE_TASK_PRIORITY		( tskIDLE_PRIORITY + 1 )
#define mainTASK_TWO_TASK_PRIORITY		( tskIDLE_PRIORITY + 1 )
#define	mainTASK_THREE_TASK_PRIORITY	( tskIDLE_PRIORITY + 2 )

/* TODO: output frequencey*/
#define mainTASK_CHATTERBOX_OUTPUT_FREQUENCY_MS		pdMS_TO_TICKS( 200UL )	

/*-----------------------------------------------------------*/

/*
 * TODO: data structure
 */
/*Defining Task Handler*/
static TaskHandle_t TASK1Handle = NULL;
static TaskHandle_t TASK2Handle = NULL;
static TaskHandle_t TASK3Handle = NULL;

struct output
{
	char ucMyString[6];
	int usFlag;
} output_read1, output_read2, output_read3;


/*
 *TODO: C function (prototype) for task
 */
static void myTask1(void* pvParameters);
static void myTask2(void* pvParameters);
static void myTask3(void* pvParameters);
/*Defining the flag variables */
static int CheckFlag (int);
static int usCount;


/*-----------------------------------------------------------*/

/*** SEE THE COMMENTS AT THE TOP OF THIS FILE ***/
void main_exercise(void)
{
	const TickType_t xTimerPeriod = mainTASK_CHATTERBOX_OUTPUT_FREQUENCY_MS;
	
	/*
	 *TODO: initialize data structures
	 */
	 /* Initializing the output string and flag values */
	 strcpy(output_read1.ucMyString, "TASK1");
	 strcpy(output_read2.ucMyString, "TASK2");
	 strcpy(output_read3.ucMyString, "TASK3");
	 output_read3.usFlag = 1;
	 output_read2.usFlag = 0;
	 output_read1.usFlag = 0;
	 	
	 /*
	  * TODO: Create the task instances.
	  */
	xTaskCreate(myTask1, "T1", 1024, NULL, mainTASK_ONE_TASK_PRIORITY,TASK1Handle);
	xTaskCreate(myTask2, "T2", 1024, NULL, mainTASK_TWO_TASK_PRIORITY,TASK2Handle);
	xTaskCreate(myTask3, "T3", 1024, NULL, mainTASK_THREE_TASK_PRIORITY,TASK3Handle);
	
	
	vTaskStartScheduler();
	
	/* If all is well, the scheduler will now be running, and the following
	line will never be reached.  If the following line does execute, then
	there was insufficient FreeRTOS heap memory available for the idle and/or
	timer tasks	to be created.  See the memory management section on the
	FreeRTOS web site for more details. */
	
	for( ;; );
}
/*-----------------------------------------------------------*/

/* 
 * TODO: C function for tasks
 */

int CheckFlag (int Flag)
{
	
	/* Check the flag value and determine the execution time of each task instances */
	  if (Flag == 0)
	  {
		  usCount = -1;  /* Inifinite instance */
	  }
	  else if (Flag == 1)
	  {
		  usCount = 5;
	  }
	  else
	  {
		  /*Do Nothing*/ 
	  }
	return  usCount;
}
void myTask1(void)
{
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_CHATTERBOX_OUTPUT_FREQUENCY_MS;
	int usExeCount;
	
	/*Get the execution count based on flag value*/
	usExeCount = CheckFlag(output_read1.usFlag);

	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	while(usExeCount > 0 || usExeCount <0)
	{
		/* Place this task in the blocked state until it is time to run again.
		The block time is specified in ticks, pdMS_TO_TICKS() was used to
		convert a time specified in milliseconds into a time specified in ticks.
		While in the Blocked state this task will not consume any CPU time. */
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
		printf("%s\n", output_read1.ucMyString);
		usExeCount--;
		
	}
}

void myTask2(void)
{
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_CHATTERBOX_OUTPUT_FREQUENCY_MS;
	int usExeCount;
	//strcpy(output_read1.ucMyString, "TASK1");
	
	/*Get the execution count based on flag value*/
	usExeCount = CheckFlag(output_read2.usFlag);

	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	while(usExeCount > 0 || usExeCount <0)
	{
		/* Place this task in the blocked state until it is time to run again.
		The block time is specified in ticks, pdMS_TO_TICKS() was used to
		convert a time specified in milliseconds into a time specified in ticks.
		While in the Blocked state this task will not consume any CPU time. */
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
		printf("%s\n", output_read2.ucMyString);
		usExeCount--;
	}
}

void myTask3(void)
{
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_CHATTERBOX_OUTPUT_FREQUENCY_MS;
	int usExeCount;
		
	/*Get the execution count based on flag value*/
	usExeCount = CheckFlag(output_read3.usFlag);

	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	while(usExeCount > 0 || usExeCount < 0)
	{
		/* Place this task in the blocked state until it is time to run again.
		The block time is specified in ticks, pdMS_TO_TICKS() was used to
		convert a time specified in milliseconds into a time specified in ticks.
		While in the Blocked state this task will not consume any CPU time. */
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
		printf("%s\n", output_read3.ucMyString);
		usExeCount--;
	}
	printf("Terminating Task 3\n");
	vTaskDelete(TASK3Handle);

}
/*-----------------------------------------------------------*/