/*
 * FreeRTOS Kernel V10.1.1
 * Copyright (C) 2018 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://www.FreeRTOS.org
 * http://aws.amazon.com/freertos
 *
 * 1 tab == 4 spaces!
 */

 /******************************************************************************
  * NOTE: Windows will not be running the FreeRTOS demo threads continuously, so
  * do not expect to get real time behaviour from the FreeRTOS Windows port, or
  * this demo application.  Also, the timing information in the FreeRTOS+Trace
  * logs have no meaningful units.  See the documentation page for the Windows
  * port for further information:
  * http://www.freertos.org/FreeRTOS-Windows-Simulator-Emulator-for-Visual-Studio-and-Eclipse-MingW.html
  *
  ******************************************************************************
  *
  * NOTE:  Console input and output relies on Windows system calls, which can
  * interfere with the execution of the FreeRTOS Windows port.  This demo only
  * uses Windows system call occasionally.  Heavier use of Windows system calls
  * can crash the port.
  */

  /* Standard includes. */
#include <stdio.h>
#include <conio.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"

#define mainNUMBER_OF_SEMAPHORS					( 3U )

// TODO

#define xTASK1_RELEASETIME  ( 10UL)
#define xTASK2_RELEASETIME  ( 3UL )
#define xTASK3_RELEASETIME  ( 5UL )
#define xTASK4_RELEASETIME  ( 0UL )


#define main_TASK1_PRIORITY		( tskIDLE_PRIORITY + 5 )
#define	main_TASK2_PRIORITY		( tskIDLE_PRIORITY + 4 )
#define	main_TASK3_PRIORITY		( tskIDLE_PRIORITY + 3 )
#define	main_TASK4_PRIORITY		( tskIDLE_PRIORITY + 2 )

#define workersUSELESS_CYCLES_PER_TIME_UNIT		( 450000000UL)

/* The rate at which data is sent to the queue.  The times are converted from
milliseconds to ticks using the pdMS_TO_TICKS() macro. */
#define mainTASK_SEND_FREQUENCY_MS			pdMS_TO_TICKS( 100000UL )
/*-----------------------------------------------------------*/

// TODO

static void usPrioritySemaphoreWait(TaskHandle_t TaskHandle_, int resourceIndex, int taskID);
static void usPrioritySemaphoreSignal(TaskHandle_t TaskHandle_, int resourceIndex, int taskID);
static void prvTask1(void* pvParameters);
static void prvTask2(void* pvParameters);
static void prvTask3(void* pvParameters);
static void prvTask4(void* pvParameters);
static void vUselessLoad(uint32_t ulCycles);

/* Task handler declaration*/
TaskHandle_t TaskHandle_1;
TaskHandle_t TaskHandle_2;
TaskHandle_t TaskHandle_3;
TaskHandle_t TaskHandle_4;

/*Store task information*/
struct task {
	int taskID;
	int int_priority; // Initial task priority
	int next_priority; //active priority	
} task[4];

/* Store semaphore data*/
struct semaphore {
	char resource;
	int priority;
	SemaphoreHandle_t xSemaphore;
} SEM[mainNUMBER_OF_SEMAPHORS];

/*-----------------------------------------------------------*/

void main_exercise(void)
{
	// TODO
	
   /* Assign task ID, priority*/
	task[0].taskID = 1;
	task[1].taskID = 2;
	task[2].taskID = 3;
	task[3].taskID = 4;

	task[0].int_priority = 5;
	task[1].int_priority = 4;
	task[2].int_priority = 3;
	task[3].int_priority = 2;

	/* Assigning the resource to semaphore*/
	SEM[0].resource = 'A';
	SEM[1].resource = 'B';
	SEM[2].resource = 'C';
	
	/*setting the ceil priority of the resources*/
	SEM[0].priority = 4;
	SEM[1].priority = 5;
	SEM[2].priority = 5;

	/*creating the semaphores*/
	SEM[0].xSemaphore = xSemaphoreCreateBinary();
	SEM[1].xSemaphore = xSemaphoreCreateBinary();
	SEM[2].xSemaphore = xSemaphoreCreateBinary();

	
	/* Creating tasks */
	 xTaskCreate(prvTask1,			/* The function that implements the task. */
		"Task1", 							/* The text name assigned to the task - for debug only as it is not used by the kernel. */
		configMINIMAL_STACK_SIZE, 		/* The size of the stack to allocate to the task. */
		NULL, 							/* The parameter passed to the task - not used in this simple case. */
		5,/* The priority assigned to the task. */
		&TaskHandle_1);							/* The task handle is not required, so NULL is passed. */

	 xTaskCreate(prvTask2,			/* The function that implements the task. */
		"Task2", 							/* The text name assigned to the task - for debug only as it is not used by the kernel. */
		configMINIMAL_STACK_SIZE, 		/* The size of the stack to allocate to the task. */
		NULL, 							/* The parameter passed to the task - not used in this simple case. */
		4,/* The priority assigned to the task. */
		&TaskHandle_2);

	 xTaskCreate(prvTask3,			/* The function that implements the task. */
		"Task3", 							/* The text name assigned to the task - for debug only as it is not used by the kernel. */
		configMINIMAL_STACK_SIZE, 		/* The size of the stack to allocate to the task. */
		NULL, 							/* The parameter passed to the task - not used in this simple case. */
		3,/* The priority assigned to the task. */
		&TaskHandle_3);

	 xTaskCreate(prvTask4,			/* The function that implements the task. */
		"Task4", 							/* The text name assigned to the task - for debug only as it is not used by the kernel. */
		configMINIMAL_STACK_SIZE, 		/* The size of the stack to allocate to the task. */
		NULL, 							/* The parameter passed to the task - not used in this simple case. */
		2,/* The priority assigned to the task. */
		&TaskHandle_4);

	

	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	/* If all is well, the scheduler will now be running, and the following
	line will never be reached.  If the following line does execute, then
	there was insufficient FreeRTOS heap memory available for the idle and/or
	timer tasks	to be created.  See the memory management section on the
	FreeRTOS web site for more details. */
	for (;; );
}
/*-----------------------------------------------------------*/

static void vUselessLoad(uint32_t ulTimeUnits) {
	uint32_t ulUselessVariable = 0;

	for (uint32_t i = 0; i < ulTimeUnits * workersUSELESS_CYCLES_PER_TIME_UNIT; i++)
	{
		ulUselessVariable = 0;
		ulUselessVariable = ulUselessVariable + 1;
	}
}

// TODO
/* Acquire resource using ICPP*/
static void usPrioritySemaphoreWait(TaskHandle_t *TaskHandle_, int resourceIndex, int taskID)
{
	
	/* Set task priority*/
	vTaskPrioritySet(TaskHandle_, SEM[resourceIndex].priority);

	//printf("Wait priority set");
	/* Change the priority of task  to the priority of the resource (semaphore)*/
	task[taskID-1].next_priority = SEM[resourceIndex].priority;

	if (SEM[resourceIndex].xSemaphore != NULL)
	{
		/* See if we can obtain the semaphore.  If the semaphore is not
		   available wait 10 ticks to see if it becomes free. */
		xSemaphoreTake(SEM[resourceIndex].xSemaphore, (TickType_t)10);
		
			//task[taskID]->next_priority=SEM[resourceIndex]->priority;
			printf("Task %d acquired resource %c and changed its priority from %d to %d\n", taskID, SEM[resourceIndex].resource, task[taskID-1].int_priority, task[taskID-1].next_priority);
		
	}
	return;
}

/* Relinquish the resource using ICPP*/
static void usPrioritySemaphoreSignal(TaskHandle_t *TaskHandle_, int resourceIndex, int taskID)
{
	/* Temp variable to store the semaphore priority*/
	int np_task = task[taskID-1].next_priority;

	/* Set task priority*/
	vTaskPrioritySet( TaskHandle_, task[taskID-1].int_priority);

	/* Change the priority of task back to its original priority*/
	task[taskID-1].next_priority = task[taskID-1].int_priority;


	if (SEM[resourceIndex].xSemaphore != NULL)
	{
		xSemaphoreGive(SEM[resourceIndex].xSemaphore);
		
			// We would expect this call to fail because we cannot give
			// a semaphore without first "taking" it! */
			printf("Task %d released resource %c and changed its priority from %d back to %d\n", taskID, SEM[resourceIndex].resource, np_task, task[taskID-1].int_priority);

		

	}
	return;
}

/* Task 1*/
static void prvTask1(void* pvParameters)
{
	// TODO
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_SEND_FREQUENCY_MS;


	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTASK1_RELEASETIME;

	for (;; )
	{
		
		vUselessLoad(1); //emulate Task doing something for 1 time unit 
		usPrioritySemaphoreWait(&TaskHandle_1, 1, 1);
		vUselessLoad(1);
		usPrioritySemaphoreSignal(&TaskHandle_1, 1, 1);
		vUselessLoad(1);
		usPrioritySemaphoreWait(&TaskHandle_1, 2, 1);
		vUselessLoad(1);
		usPrioritySemaphoreSignal(&TaskHandle_1, 2, 1);
		vUselessLoad(1);

		/* Place this task in the blocked state until it is time to run again.
		The block time is specified in ticks, pdMS_TO_TICKS() was used to
		convert a time specified in milliseconds into a time specified in ticks.
		While in the Blocked state this task will not consume any CPU time.
		*/
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
	}

}
/* Task 2*/
static void prvTask2(void* pvParameters)
{
	// TODO
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_SEND_FREQUENCY_MS;


	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTASK2_RELEASETIME;
	for (;; )
	{
		
		vUselessLoad(1); //emulate Task doing something for 1 time unit 
		usPrioritySemaphoreWait(&TaskHandle_2,2, 2);
		vUselessLoad(2);
		usPrioritySemaphoreSignal(&TaskHandle_2,2, 2);
		vUselessLoad(2);
		usPrioritySemaphoreWait(&TaskHandle_2,0,2);
		vUselessLoad(1);
		usPrioritySemaphoreSignal(&TaskHandle_2,0,2);
		vUselessLoad(1);

		/* Place this task in the blocked state until it is time to run again.
	The block time is specified in ticks, pdMS_TO_TICKS() was used to
	convert a time specified in milliseconds into a time specified in ticks.
	While in the Blocked state this task will not consume any CPU time.
	*/
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
	}
	
}
/* Task 3*/
static void prvTask3(void* pvParameters)
{
	// TODO
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_SEND_FREQUENCY_MS;


	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTASK2_RELEASETIME;
	for (;; )
	{
		
		vUselessLoad(2); //emulate Task doing something for 1 time unit 
		usPrioritySemaphoreWait(&TaskHandle_3,1, 3);
		vUselessLoad(1);
		usPrioritySemaphoreWait(&TaskHandle_3,0, 3);
		vUselessLoad(2);
		usPrioritySemaphoreSignal(&TaskHandle_3,0,3);
		vUselessLoad(2);
		usPrioritySemaphoreSignal(&TaskHandle_3, 1, 3);
		vUselessLoad(1);
		/* Place this task in the blocked state until it is time to run again.
		The block time is specified in ticks, pdMS_TO_TICKS() was used to
		convert a time specified in milliseconds into a time specified in ticks.
		While in the Blocked state this task will not consume any CPU time.
		*/
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
	}
}
/* Task 4*/
static void prvTask4(void* pvParameters)
{
	// TODO
	TickType_t xNextWakeTime;
	const TickType_t xBlockTime = mainTASK_SEND_FREQUENCY_MS;

	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTASK2_RELEASETIME;

	for (;; )
	{
		vUselessLoad(2); //emulate Task doing something for 1 time unit 
		usPrioritySemaphoreWait(&TaskHandle_4, 0, 4);
		vUselessLoad(2);
		usPrioritySemaphoreWait(&TaskHandle_4, 1, 4);
		vUselessLoad(2);
		
		usPrioritySemaphoreSignal(&TaskHandle_4, 1, 4);
		
		vUselessLoad(2);
		usPrioritySemaphoreSignal(&TaskHandle_4, 0, 4);
		vUselessLoad(1);
		/* Place this task in the blocked state until it is time to run again.
	The block time is specified in ticks, pdMS_TO_TICKS() was used to
	convert a time specified in milliseconds into a time specified in ticks.
	While in the Blocked state this task will not consume any CPU time.
	*/
		vTaskDelayUntil(&xNextWakeTime, xBlockTime);
	}
	
}