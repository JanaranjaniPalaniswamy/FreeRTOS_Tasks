For MSVC: open project from .\FreeRTOS\IPC-App\WIN32-MSVC\WIN32.sln

NOTE: Upgrade to the recommended Platform Toolset if required by Visual Studio IDE.

There is a main.c file in the project which is the entry point. Source code changes are done in main_exercise.c file according to the requirement given in exercise sheet, which contains the actual PCP application code.







