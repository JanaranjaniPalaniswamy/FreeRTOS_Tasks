/******************************************************************************
 * NOTE: Windows will not be running the FreeRTOS demo threads continuously, so
 * do not expect to get real time behaviour from the FreeRTOS Windows port, or
 * this demo application.  Also, the timing information in the FreeRTOS+Trace
 * logs have no meaningful units.  See the documentation page for the Windows
 * port for further information:
 * http://www.freertos.org/FreeRTOS-Windows-Simulator-Emulator-for-Visual-Studio-and-Eclipse-MingW.html
/* Standard includes. */
#include <stdio.h>
#include <assert.h>
#include <conio.h>


/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"
#include "queue.h"

/* TODO */
/* The number of items the queue can hold at once. */
#define mainQUEUE_LENGTH					( 20 )

/* Priorities at which the tasks are created. */
#define mainSENSOR1	       ( tskIDLE_PRIORITY + 3 )
#define	mainSENSOR2A	   ( tskIDLE_PRIORITY + 2 )
#define	mainSENSOR2B		( tskIDLE_PRIORITY + 1 )
#define mainController1	       ( tskIDLE_PRIORITY + 4 )
#define mainController2	       ( tskIDLE_PRIORITY )

/*
* The tasks declaration
*/
static void prvSensor1(void* pvParameters);
static void prvSensor2A(void* pvParameters);
static void prvSensor2B(void* pvParameters);
static void prvController1(void* pvParameters);
static void prvController2(void* pvParameters);

/* The queue used by both tasks. */
static QueueHandle_t xQueue1, xQueue2A, xQueue2B;

static QueueSetHandle_t xQueueSet;

QueueSetMemberHandle_t xActivatedMember;	//Used in controller 1
QueueSetMemberHandle_t xActivatedMember2;	//Used in controller 2


void main_exercise(void)
{
	/* TODO */
	 /* Create the queue. */
	xQueue1 = xQueueCreate(mainQUEUE_LENGTH, sizeof(uint32_t));
	xQueue2A = xQueueCreate(mainQUEUE_LENGTH, sizeof(uint32_t));
	xQueue2B = xQueueCreate(mainQUEUE_LENGTH, sizeof(uint32_t));

	/* Check everything was created. */
	configASSERT(xQueue1);
	configASSERT(xQueue2A);
	configASSERT(xQueue2B);

	if ((xQueue1 != NULL) && (xQueue2A != NULL) && (xQueue2B != NULL))
	{
		/* Start the two tasks as described in the comments at the top of this
		file. */
		xTaskCreate(prvSensor1,			/* The function that implements the task. */
			"TX1", 							/* The text name assigned to the task - for debug only as it is not used by the kernel. */
			configMINIMAL_STACK_SIZE, 		/* The size of the stack to allocate to the task. */
			NULL, 							/* The parameter passed to the task - not used in this simple case. */
			mainSENSOR1,                    /* The priority assigned to the task. */
			NULL);							/* The task handle is not required, so NULL is passed. */

		xTaskCreate(prvSensor2A, "TX2A", configMINIMAL_STACK_SIZE, NULL, mainSENSOR2A, NULL);
		xTaskCreate(prvSensor2B, "TX2B", configMINIMAL_STACK_SIZE, NULL, mainSENSOR2B, NULL);

		xTaskCreate(prvController1, "RX1", configMINIMAL_STACK_SIZE, NULL, mainController1, NULL);
	
	/* Create the queue set large enough to hold an event for every space in
	every queue  that is to be added to the set. */
	xQueueSet = xQueueCreateSet(2);


	/* Add the queues and semaphores to the set.  Reading from these queues and
	 semaphore can only be performed after a call to xQueueSelectFromSet() has
	 returned the queue or semaphore handle from this point on. */

	xQueueAddToSet(xQueue2A, xQueueSet);
	xQueueAddToSet(xQueue2B, xQueueSet);

		/* Start the tasks and timer running. */
		vTaskStartScheduler();
	}

	for (;; );

}
/*-----------------------------------------------------------*/


static void prvController1(void* pvParameters)
{
	int data1, data2;
	int timer_value = 0;
	int xReceivedFromQueue1;
	int xReceivedFromQueue2A;
	int xReceivedFromQueue2B;

	const TickType_t xDelay = 300 / portTICK_PERIOD_MS;

	/* Prevent the compiler warning about the unused parameter. */
	(void)pvParameters;


	for (;;)
	{
		xActivatedMember = xQueueSelectFromSet(xQueueSet, 100 / portTICK_PERIOD_MS);

		if (xActivatedMember == xQueue2A)
		{
			xQueueReceive(xActivatedMember, &xReceivedFromQueue2A, 0U);
			data2 = xReceivedFromQueue2A;
			timer_value = xTaskGetTickCount();
		}
		else if (xActivatedMember == xQueue2B)
		{
			xQueueReceive(xActivatedMember, &xReceivedFromQueue2B, 0U);
			data2 = xReceivedFromQueue2B;
			timer_value = xTaskGetTickCount();
		}
		else
		{
			timer_value = xTaskGetTickCount();
			printf("Controller 1 has had an error at %d \n",timer_value);
			vTaskDelay(1);
			xTaskCreate(prvController2, "RX2", configMINIMAL_STACK_SIZE, NULL, mainController2 + 4, NULL);	//Task Controller 2 should have the same priority as Task Controller 1.
			vTaskDelay(xDelay);

			break;
		}
		
		xQueueReceive(xQueue1, &xReceivedFromQueue1, 0U);
		data1 = xReceivedFromQueue1;
		printf("Controller 1 has received sensor data at %d: Sensor1: %d; Sensor2: %d \n", timer_value, data1, data2);
		vTaskDelay(xDelay);
		//break;
	}
}
static void prvController2(void* pvParameters)
{
	int data1;
	int data2;
	int timer_value2;
	int xReceivedFromQueue1;
	int xReceivedFromQueue2A;
	int xReceivedFromQueue2B;
	

	const TickType_t xDelay = 500 / portTICK_PERIOD_MS;

	/* Prevent the compiler warning about the unused parameter. */
	(void)pvParameters;

	for (;;)
	{
		xActivatedMember2 = xQueueSelectFromSet(xQueueSet, 100 / portTICK_PERIOD_MS);

		if (xActivatedMember2 == xQueue2A)
		{
			xQueueReceive(xActivatedMember2, &xReceivedFromQueue2A, 0U);
			data2 = xReceivedFromQueue2A;
			timer_value2 = xTaskGetTickCount();
		}
		else if (xActivatedMember2 == xQueue2B)
		{
			xQueueReceive(xActivatedMember2, &xReceivedFromQueue2B, 0U);
			data2 = xReceivedFromQueue2B;
			timer_value2 = xTaskGetTickCount();
		}
		else
		{
			printf("Controller 2 fails");
			break;
		}
		xQueueReceive(xQueue1, &xReceivedFromQueue1, 0U);
		data1 = xReceivedFromQueue1;
		printf("Controller 2 has received sensor data at %d : Sensor1: %d; Sensor2: %d \n", timer_value2, data1, data2);
		vTaskDelay(xDelay);
	}
}


/* TODO */
/*-----------------------------------------------------------*/
static void prvSensor1(void* pvParameters)
{
	/*200ms interval for each counter increment*/
	const TickType_t xDelay = 200 / portTICK_PERIOD_MS;

	/* Prevent the compiler warning about the unused parameter. */
	(void)pvParameters;

	int value1 = 100;
	for (;; )
	{
		if (value1 == 199)
		{
			value1 = 100;
		}
		else
		{
			value1++;
		}
		xQueueSend(xQueue1, &value1, 0U);

		vTaskDelay(xDelay);

	}

}

static void prvSensor2A(void* pvParameters)
{
	/*500ms interval for each counter increment*/
	const TickType_t xDelay = 500 / portTICK_PERIOD_MS;

	/* Prevent the compiler warning about the unused parameter. */
	(void)pvParameters;

	int value2a = 200;
	for (;; )
	{
		if (value2a == 249)
		{
			value2a = 200;
		}
		else
		{
			value2a++;
		}
		xQueueSend(xQueue2A, &value2a, 0U);

		vTaskDelay(xDelay);

	}
}
static void prvSensor2B(void* pvParameters)
{
	/*1400ms interval for each counter increment*/
	const TickType_t xDelay = 1400 / portTICK_PERIOD_MS;

	/* Prevent the compiler warning about the unused parameter. */
	(void)pvParameters;

	int value2b = 250;
	for (;; )
	{
		if (value2b == 299)
		{
			value2b = 250;
		}
		else
		{
			value2b++;
		}
		xQueueSend(xQueue2B, &value2b, 0U);

		vTaskDelay(xDelay);

	}
}


